Project: Search the Closest Location

Config Changes:
1. .csv file path is mentioned in web.config

Assumptions:

1. The Data is obtained from the .csv file which was given which also consists of Latitude and Longitude data.
2. We have calculated the distance using an algorithm mention here https://www.geodatasource.com