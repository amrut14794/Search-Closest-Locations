Project: Search the Closest Location

Config Changes:
1. AustralaAddressDemo.csv file path is mentioned in web.config

Assumptions:

1. The Data is obtained from the .csv file which was given which also consists of Latitude and Longitude data.
2. We have calculated the distance using an algorithm mention here https://www.geodatasource.com

Note: The Code for Calculating the Closest Distance will work once the GoogleAPIs mentioned in the code are accessible.
Since GoogleAPI is not accessible, the Latitudes and Longitudes are mentioned the .csv file for some locations.