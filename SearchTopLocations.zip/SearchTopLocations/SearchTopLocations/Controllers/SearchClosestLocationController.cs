﻿using SearchTopLocations.Helper;
using SearchTopLocations.Models;
using SearchTopLocations.Models.GoogleAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;

namespace SearchTopLocations.Controllers
{
    public class SearchClosestLocationController : Controller
    {
        // GET: SearchClosestLocation
        public ActionResult Index()
        {
            AddressInformation model = new AddressInformation();
            return PartialView("~/Views/SearchClosestLocation/SearchClosestLocations.cshtml", model);
        }

        [HttpPost]
        public ActionResult SubmitSearchPlaces(string data, FormCollection collection)
        {
            string SearchText = data;
            string AddressPath = "";
            AddressInformation AdInfo = new AddressInformation();
            AddressPath = WebConfigurationManager.AppSettings["AddressPath"];
            GetAddressInformation AddrObj = new GetAddressInformation();
            List<AddressInformation> ListAdInfo = new List<AddressInformation>();
            List<GetAddressInformation> UpdatedAddrObj = new List<GetAddressInformation>();
            List<string> AddressList = AddrObj.GetAddressDetailsCsv(AddressPath);
            ListAdInfo = AddrObj.ReorderdAddressObject(AddressList);

            AddressInformation UpdatedAddrInfo = GoogleGeoLocation.GetCoordinates(SearchText);
            if (!string.IsNullOrEmpty(SearchText))
            {
                foreach (AddressInformation address in ListAdInfo)
                {
                    if (address != null)
                    {
                        address.Distance = CalcDistance(address.Latitude, UpdatedAddrInfo.Latitude, address.Longitude, UpdatedAddrInfo.Longitude, 'K');
                    }
                }
                AdInfo.FinalAddressList = ListAdInfo.OrderBy(x => x.Distance).Take(5).ToList();
                return PartialView("~/Views/SearchClosestLocation/SearchClosestLocations.cshtml", AdInfo);
            }
            return null;
        }
        public double CalcDistance(double Latitude, double UpdatedLatitude, double Longitude, double UpdatedLongitude, char character)
        {
            if (Latitude != UpdatedLatitude && Longitude != UpdatedLongitude)
            {
                double Diff = Longitude - UpdatedLongitude;
                //Converting degree to radian and radian to degree wherever necessary
                double dist = Math.Sin(deg2rad(Latitude)) * Math.Sin(deg2rad(UpdatedLatitude)) + Math.Cos(deg2rad(Latitude)) * Math.Cos(deg2rad(UpdatedLatitude)) * Math.Cos(deg2rad(Diff));
                dist = Math.Acos(dist);
                dist = rad2deg(dist);
                dist = dist * 60 * 1.1515;
                if (character == 'K')
                {
                    dist = dist * 1.609344;
                }
                else if (character == 'N')
                {
                    dist = dist * 0.8684;
                }
                return (dist);
            }
            else
            {
                return 0;
            }
        }
        static private double deg2rad(double deg)
        {
            return (deg * Math.PI / 180.0);
        }

        static private double rad2deg(double rad)
        {
            return (rad / Math.PI * 180.0);
        }
    }
}