﻿using SearchTopLocations.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace SearchTopLocations.Helper
{
    public class GetAddressInformation
    {
        public List<string> GetAddressDetailsCsv(string AddressPath)
        {
            List<string> Address = new List<string>();
            using (var reader = new StreamReader(AddressPath))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(';');

                    Address.AddRange(values);
                }
            }
            return Address;
        }
        public List<AddressInformation> ReorderdAddressObject(List<string> AddressList)
        {
            List<AddressInformation> ListAddrInfo = new List<AddressInformation>();
            foreach (string Address in AddressList)
            {
                AddressInformation AddrInfo = new AddressInformation();
                var splitAddress = Address.Replace("\"", "").Replace("\\", "").Split(',');
                AddrInfo.Latitude = Convert.ToDouble(splitAddress[splitAddress.Length - 2]);
                AddrInfo.Longitude = Convert.ToDouble(splitAddress[splitAddress.Length - 1]);
                AddrInfo.FullAddress = splitAddress[0] + ", " + splitAddress[1];
                ListAddrInfo.Add(AddrInfo);
            }
            return ListAddrInfo;
        }
    }
}