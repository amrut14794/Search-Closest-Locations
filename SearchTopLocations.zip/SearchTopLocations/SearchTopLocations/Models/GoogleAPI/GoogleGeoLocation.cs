﻿using SearchTopLocations.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;

namespace SearchTopLocations.Models.GoogleAPI
{
    public static class GoogleGeoLocation
    {
        static string GoogleApi = "https://maps.googleapis.com/maps/api/geocode/json?{0}&key=YOUR_API_KEY";

        /// <summary>
        /// Get the geo location (lat/long) of address prvided
        /// </summary>
        /// <param name="address">address input</param>
        /// <returns></returns>
        public static AddressInformation GetCoordinates(string address)
        {
            try
            {
                AddressInformation InputAddress = new AddressInformation();
                InputAddress.FullAddress = address;
                GoogleApi = string.Format(GoogleApi, address);
                WebRequest request = WebRequest.Create(GoogleApi);
                WebResponse response = request.GetResponse();
                Stream data = response.GetResponseStream();
                StreamReader reader = new StreamReader(data);
                string geCdjson = reader.ReadToEnd();
                response.Close();

                //TODO: parse json and return lat/long in dictionary
                InputAddress.Latitude = Convert.ToDouble("-32.12212");
                InputAddress.Longitude = Convert.ToDouble("16.12412");
                return InputAddress;
            }
            catch (WebException webex)
            {
                AddressInformation InputAddress = new AddressInformation();
                InputAddress.FullAddress = address;
                InputAddress.Latitude = Convert.ToDouble("-32.12212");
                InputAddress.Longitude = Convert.ToDouble("16.12412");
                return InputAddress;
            }
        }
    }
}